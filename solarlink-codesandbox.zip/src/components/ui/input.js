export const Input = ({ type, placeholder, value, onChange }) => (
  <input type={type} placeholder={placeholder} value={value} onChange={onChange}
         className="w-full border border-gray-300 px-2 py-1 rounded" />
);