export const Tabs = ({ children }) => <div>{children}</div>;
export const TabsList = ({ children, className }) => <div className={className}>{children}</div>;
export const TabsTrigger = ({ children }) => <button className="bg-gray-200 px-3 py-1 rounded">{children}</button>;
export const TabsContent = ({ children }) => <div className="mt-2">{children}</div>;