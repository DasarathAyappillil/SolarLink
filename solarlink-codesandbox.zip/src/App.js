import { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./components/ui/tabs";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";

export default function App() {
  const [balance, setBalance] = useState(3000);
  const [buyUnits, setBuyUnits] = useState(0);
  const [sellUnits, setSellUnits] = useState(1.6);
  const [sellRate, setSellRate] = useState(4.2);

  const calculateKeralaRate = (units) => {
    if (units <= 40) return 3.15;
    if (units <= 100) return 4.70;
    if (units <= 150) return 6.25;
    if (units <= 200) return 7.60;
    return 7.90;
  };

  const buyFromMarket = (price, units) => {
    const cost = price * units;
    if (balance >= cost) {
      setBalance(prev => prev - cost);
      alert(`Purchased ${units} units from market for ₹${cost.toFixed(2)}`);
    } else {
      alert("Insufficient balance.");
    }
  };

  return (
    <main className="p-4 max-w-md mx-auto text-center font-sans">
      <h1 className="text-2xl font-bold text-yellow-500">SolarLink</h1>
      <p className="text-sm text-gray-500 mb-4">Power to the People</p>

      <Card className="mb-4">
        <CardContent className="p-4">
          <p className="text-lg font-semibold">Balance: ₹{balance}</p>
        </CardContent>
      </Card>

      <Tabs defaultValue="buy">
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="buy">Buy</TabsTrigger>
          <TabsTrigger value="sell">Sell</TabsTrigger>
          <TabsTrigger value="market">Market</TabsTrigger>
        </TabsList>

        <TabsContent value="buy">
          <Card className="mt-4">
            <CardContent className="p-4 space-y-2">
              <h2 className="font-bold">Buy Electricity</h2>
              <Input
                type="number"
                placeholder="Units to buy"
                onChange={(e) => setBuyUnits(Number(e.target.value))}
              />
              <p>Estimated Cost: ₹{(buyUnits * calculateKeralaRate(buyUnits)).toFixed(2)}</p>
              <Button onClick={() => {
                const cost = buyUnits * calculateKeralaRate(buyUnits);
                if (balance >= cost) {
                  setBalance(balance - cost);
                  alert(`Purchased ${buyUnits} units for ₹${cost.toFixed(2)}`);
                } else {
                  alert("Insufficient balance.");
                }
              }}>Buy Now</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sell">
          <Card className="mt-4">
            <CardContent className="p-4 space-y-2">
              <h2 className="font-bold">Sell Electricity</h2>
              <p>Available: {sellUnits} kWh</p>
              <Input
                type="number"
                placeholder="Set Rate ₹/unit"
                value={sellRate}
                onChange={(e) => setSellRate(e.target.value)}
              />
              <Button onClick={() => alert('Electricity listed for sale!')}>List Now</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="market">
          <Card className="mt-4">
            <CardContent className="p-4">
              <h2 className="font-bold mb-2">Live Offers</h2>
              <div className="space-y-2">
                <div className="p-2 bg-gray-100 rounded cursor-pointer" onClick={() => buyFromMarket(4.3, 2.0)}>👤 Dasarath - ₹4.3/unit - 2.0 kWh</div>
                <div className="p-2 bg-gray-100 rounded cursor-pointer" onClick={() => buyFromMarket(4.0, 1.5)}>👤 Arnav - ₹4.0/unit - 1.5 kWh</div>
                <div className="p-2 bg-gray-100 rounded cursor-pointer" onClick={() => buyFromMarket(4.6, 0.9)}>👤 Sathwik - ₹4.6/unit - 0.9 kWh</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
}