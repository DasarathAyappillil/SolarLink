import React from 'react';
import { Shield, FileText, CheckCircle, ExternalLink } from 'lucide-react';

const Policy = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-blue-100 text-blue-800 px-6 py-3 rounded-full font-semibold mb-6">
            <Shield className="h-5 w-5 mr-2" />
            Government Approved
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Backed by Kerala's 2025 Policy
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            SolarLink operates under Kerala's groundbreaking peer-to-peer energy trading regulations, 
            ensuring legal compliance and consumer protection
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="bg-white rounded-2xl p-8 shadow-xl">
              <div className="flex items-center mb-6">
                <FileText className="h-8 w-8 text-blue-600 mr-3" />
                <h3 className="text-2xl font-bold text-gray-900">Policy Highlights</h3>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-gray-900">KSEB Grid Integration</div>
                    <div className="text-gray-600">Official approval for P2P trading through existing grid infrastructure</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-gray-900">Smart Meter Mandate</div>
                    <div className="text-gray-600">Requirement for advanced metering infrastructure to enable fair trading</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-gray-900">Consumer Protection</div>
                    <div className="text-gray-600">Regulatory safeguards ensuring transparent pricing and fair market access</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-gray-900">Renewable Energy Priority</div>
                    <div className="text-gray-600">Focus on promoting solar and other clean energy sources in the trading ecosystem</div>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <button className="flex items-center text-blue-600 hover:text-blue-700 font-semibold transition-colors">
                  Read Full Policy Document
                  <ExternalLink className="h-4 w-4 ml-2" />
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">2025</div>
              <div className="font-semibold text-gray-900 mb-2">Policy Effective Date</div>
              <div className="text-gray-600">Kerala becomes the first Indian state to enable residential P2P energy trading</div>
            </div>
            
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">100%</div>
              <div className="font-semibold text-gray-900 mb-2">Grid Compatible</div>
              <div className="text-gray-600">Seamless integration with existing KSEB infrastructure and billing systems</div>
            </div>
            
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">₹0</div>
              <div className="font-semibold text-gray-900 mb-2">Registration Fee</div>
              <div className="text-gray-600">No additional charges for participating in the P2P trading program</div>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-6 rounded-2xl inline-block">
            <div className="font-semibold text-lg mb-2">Kerala State Electricity Board (KSEB)</div>
            <div className="text-blue-100">Official Partner for Grid Operations and Billing</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Policy;