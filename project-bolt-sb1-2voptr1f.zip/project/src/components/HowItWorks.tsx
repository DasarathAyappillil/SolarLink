import React from 'react';
import { Sun, Smartphone, Zap, ArrowRight } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: Sun,
      title: "Generate Solar Energy",
      description: "Solar panel owners generate clean electricity and register excess energy on the SolarLink platform",
      color: "yellow"
    },
    {
      icon: Smartphone,
      title: "Smart Trading App",
      description: "Browse available energy, compare prices, and make instant purchases through our mobile app",
      color: "blue"
    },
    {
      icon: Zap,
      title: "Automatic Transfer",
      description: "Smart meters handle the transfer seamlessly while KSEB grid ensures reliable distribution",
      color: "green"
    }
  ];

  const colorClasses = {
    yellow: {
      bg: "bg-yellow-100",
      icon: "text-yellow-600",
      accent: "bg-yellow-500"
    },
    blue: {
      bg: "bg-blue-100",
      icon: "text-blue-600",
      accent: "bg-blue-500"
    },
    green: {
      bg: "bg-green-100",
      icon: "text-green-600",
      accent: "bg-green-500"
    }
  };

  return (
    <section id="how-it-works" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Three simple steps to revolutionize your energy consumption
          </p>
        </div>

        <div className="relative">
          {/* Mobile layout */}
          <div className="lg:hidden space-y-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const colors = colorClasses[step.color as keyof typeof colorClasses];
              
              return (
                <div key={index} className="bg-white rounded-2xl p-8 shadow-lg">
                  <div className="text-center">
                    <div className={`w-20 h-20 ${colors.bg} rounded-2xl flex items-center justify-center mx-auto mb-6`}>
                      <Icon className={`h-10 w-10 ${colors.icon}`} />
                    </div>
                    <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-sm font-bold text-gray-600">{index + 1}</span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">{step.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{step.description}</p>
                  </div>
                  {index < steps.length - 1 && (
                    <div className="flex justify-center mt-8">
                      <ArrowRight className="h-6 w-6 text-gray-400 rotate-90" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Desktop layout */}
          <div className="hidden lg:block">
            <div className="grid lg:grid-cols-3 gap-12 relative">
              {/* Connection lines */}
              <div className="absolute top-24 left-1/6 right-1/6 h-0.5 bg-gradient-to-r from-yellow-300 via-blue-300 to-green-300"></div>
              
              {steps.map((step, index) => {
                const Icon = step.icon;
                const colors = colorClasses[step.color as keyof typeof colorClasses];
                
                return (
                  <div key={index} className="relative">
                    <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center relative z-10">
                      <div className={`w-20 h-20 ${colors.bg} rounded-2xl flex items-center justify-center mx-auto mb-6 relative`}>
                        <Icon className={`h-10 w-10 ${colors.icon}`} />
                        <div className={`absolute -top-2 -right-2 w-8 h-8 ${colors.accent} rounded-full flex items-center justify-center`}>
                          <span className="text-sm font-bold text-white">{index + 1}</span>
                        </div>
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-4">{step.title}</h3>
                      <p className="text-gray-600 leading-relaxed">{step.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center bg-white px-8 py-4 rounded-full shadow-lg">
            <Zap className="h-5 w-5 text-yellow-500 mr-2" />
            <span className="font-semibold text-gray-900">Powered by Kerala's Smart Grid Infrastructure</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;