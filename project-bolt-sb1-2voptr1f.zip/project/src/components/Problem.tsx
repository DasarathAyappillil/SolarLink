import React from 'react';
import { TrendingUp, Zap, AlertTriangle } from 'lucide-react';

const Problem = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            The Energy Crisis We Face
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Traditional energy systems are failing consumers and the environment
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mb-6">
              <TrendingUp className="h-8 w-8 text-red-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Rising Power Bills
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Electricity costs continue to soar, putting financial strain on families and businesses. 
              Traditional grid pricing offers no flexibility or choice for consumers.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mb-6">
              <Zap className="h-8 w-8 text-orange-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Wasted Solar Energy
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Solar panel owners generate excess clean energy that goes unused, while neighbors 
              continue relying on expensive, polluting grid electricity.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mb-6">
              <AlertTriangle className="h-8 w-8 text-gray-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Inefficient Grid
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Centralized power distribution leads to transmission losses, grid instability, 
              and limited consumer control over energy choices.
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center bg-yellow-100 text-yellow-800 px-8 py-4 rounded-full font-semibold">
            <AlertTriangle className="h-5 w-5 mr-2" />
            It's time for a smarter, fairer energy system
          </div>
        </div>
      </div>
    </section>
  );
};

export default Problem;