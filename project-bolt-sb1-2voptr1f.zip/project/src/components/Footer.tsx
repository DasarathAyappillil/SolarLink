import React from 'react';
import { Sun, Mail, Phone, MapPin, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand section */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="relative">
                <Sun className="h-8 w-8 text-yellow-500" />
                <div className="absolute inset-0 bg-yellow-400 rounded-full blur-md opacity-30 animate-pulse"></div>
              </div>
              <span className="text-2xl font-bold">SolarLink</span>
            </div>
            <p className="text-gray-300 leading-relaxed max-w-lg mb-6">
              Revolutionizing Kerala's energy landscape through peer-to-peer solar electricity trading. 
              Empowering communities with clean, affordable, and sustainable energy solutions.
            </p>
            <div className="text-sm text-gray-400">
              A student entrepreneurship project from Bhavan's Munshi Vidyashram
            </div>
          </div>

          {/* Contact section */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Contact Us</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-yellow-500" />
                <span className="text-gray-300">hello@solarlink.in</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-yellow-500" />
                <span className="text-gray-300">+91 98765 43210</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-yellow-500" />
                <span className="text-gray-300">Kerala, India</span>
              </div>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <div className="space-y-3">
              <a href="#solution" className="block text-gray-300 hover:text-yellow-500 transition-colors">
                Our Solution
              </a>
              <a href="#how-it-works" className="block text-gray-300 hover:text-yellow-500 transition-colors">
                How It Works
              </a>
              <a href="#benefits" className="block text-gray-300 hover:text-yellow-500 transition-colors">
                Benefits
              </a>
              <a href="#team" className="block text-gray-300 hover:text-yellow-500 transition-colors">
                Team
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-400 text-sm mb-4 md:mb-0">
            © 2024 SolarLink. All rights reserved. | Bhavan's Munshi Vidyashram Student Project
          </div>
          
          <button
            onClick={scrollToTop}
            className="bg-yellow-500 hover:bg-yellow-600 text-white p-3 rounded-full transition-colors shadow-lg hover:shadow-xl"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;