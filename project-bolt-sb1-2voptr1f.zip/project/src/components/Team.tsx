import React from 'react';
import { Linkedin, Github, Mail, GraduationCap } from 'lucide-react';

const Team = () => {
  const teamMembers = [
    {
      name: "Dasarath Ayappillil",
      role: "CEO & Co-Founder",
      description: "Passionate about renewable energy and sustainable technology solutions for Kerala's energy future.",
      image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      social: {
        linkedin: "#",
        github: "#",
        email: "dasarath@solarlink.in"
      }
    },
    {
      name: "Arnav Anupkumar",
      role: "CTO & Co-Founder",
      description: "Tech enthusiast focused on building scalable platforms for peer-to-peer energy trading systems.",
      image: "https://images.pexels.com/photos/3777931/pexels-photo-3777931.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      social: {
        linkedin: "#",
        github: "#",
        email: "arnav@solarlink.in"
      }
    },
    {
      name: "Sathwik Madhav",
      role: "COO & Co-Founder",
      description: "Operations specialist ensuring seamless user experience and regulatory compliance for SolarLink.",
      image: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      social: {
        linkedin: "#",
        github: "#",
        email: "sathwik@solarlink.in"
      }
    }
  ];

  return (
    <section id="team" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-yellow-100 text-yellow-800 px-6 py-3 rounded-full font-semibold mb-6">
            <GraduationCap className="h-5 w-5 mr-2" />
            Student Entrepreneurs
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Meet Our Team
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Three passionate students from Bhavan's Munshi Vidyashram working to revolutionize 
            Kerala's energy landscape through innovation and technology
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="relative">
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
              </div>
              
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{member.name}</h3>
                <div className="text-yellow-600 font-semibold mb-4">{member.role}</div>
                <p className="text-gray-600 leading-relaxed mb-6">{member.description}</p>
                
                <div className="flex space-x-4">
                  <a 
                    href={member.social.linkedin}
                    className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-200 transition-colors"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                  <a 
                    href={member.social.github}
                    className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                  <a 
                    href={`mailto:${member.social.email}`}
                    className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 hover:bg-green-200 transition-colors"
                  >
                    <Mail className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg inline-block">
            <div className="flex items-center justify-center mb-4">
              <GraduationCap className="h-8 w-8 text-yellow-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">Bhavan's Munshi Vidyashram</h3>
            </div>
            <p className="text-gray-600 max-w-2xl">
              Proud students of Bhavan's Munshi Vidyashram, working on innovative solutions 
              to address real-world challenges in renewable energy and sustainable development.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;