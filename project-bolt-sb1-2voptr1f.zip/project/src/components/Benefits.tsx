import React from 'react';
import { Leaf, IndianRupee, Zap, TrendingDown, Shield, Users } from 'lucide-react';

const Benefits = () => {
  const benefits = [
    {
      icon: IndianRupee,
      title: "Lower Energy Bills",
      description: "Save up to 50% on electricity costs by buying directly from local solar producers at competitive rates",
      color: "green"
    },
    {
      icon: Leaf,
      title: "100% Clean Energy",
      description: "Support renewable energy and reduce your carbon footprint with guaranteed solar-sourced electricity",
      color: "emerald"
    },
    {
      icon: Zap,
      title: "Smart Grid Integration",
      description: "Seamless integration with KSEB's infrastructure ensures reliable power delivery and grid stability",
      color: "blue"
    },
    {
      icon: TrendingDown,
      title: "Reduced Waste",
      description: "Eliminate energy waste by enabling efficient local distribution of excess solar power",
      color: "orange"
    },
    {
      icon: Shield,
      title: "Secure Transactions",
      description: "Blockchain-secured smart contracts ensure transparent, fair, and automated energy trading",
      color: "purple"
    },
    {
      icon: Users,
      title: "Community Building",
      description: "Foster local energy independence and create sustainable neighborhood energy networks",
      color: "cyan"
    }
  ];

  const colorClasses = {
    green: "from-green-500 to-emerald-500",
    emerald: "from-emerald-500 to-teal-500",
    blue: "from-blue-500 to-cyan-500",
    orange: "from-orange-500 to-red-500",
    purple: "from-purple-500 to-pink-500",
    cyan: "from-cyan-500 to-blue-500"
  };

  return (
    <section id="benefits" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Why Choose SolarLink?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transform the way you consume energy with benefits that matter to you and the planet
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            const gradientClass = colorClasses[benefit.color as keyof typeof colorClasses];
            
            return (
              <div 
                key={index} 
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 hover:border-gray-200"
              >
                <div className={`w-16 h-16 bg-gradient-to-r ${gradientClass} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-gray-700 transition-colors">
                  {benefit.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Stats section */}
        <div className="mt-20 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-3xl p-12">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Impact That Matters
            </h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Join thousands of Kerala residents already benefiting from peer-to-peer energy trading
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-yellow-600 mb-2">₹2,500</div>
              <div className="text-gray-700 font-medium">Average Monthly Savings</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">85%</div>
              <div className="text-gray-700 font-medium">Carbon Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">1,200+</div>
              <div className="text-gray-700 font-medium">Active Traders</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">24/7</div>
              <div className="text-gray-700 font-medium">Platform Availability</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;